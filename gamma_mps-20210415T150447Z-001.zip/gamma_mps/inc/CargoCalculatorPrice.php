<?php


/**
*
*/
class CargoCalculatorPrice
{

    public $country;
    public $city;
    public $typeCargo; // avalible ['gc', 'dg', 'hum', 'val']
    public $weight;
    public $sizeCargo = ['width' => 0, 'length' => 0, 'height' => 0];
    public $forCity;
    private $sheets = [];
    //keys
    /*
    * A - city
    * B - country
    */

    private $optionName = 'cargo_export';

    function __construct($config){


        foreach ($config as $key => $value) {

            if(property_exists($this, $key) && $value){
                $this->$key = $value;
            }

        }

        $this->setSheets();

    }


    public function calculatePrice(){
        $this->prepareNumbers();

        $sizeMass = $this->sizeCargo['width'] * $this->sizeCargo['length'] * $this->sizeCargo['height'] * 167;

        $weight = ( $this->weight > $sizeMass ) ? $this->weight : $sizeMass;

        $data = $this->getData();

        $suitRows = [];
        foreach ($data as $key => $value) {
            if($value['B'] == $this->country && $value['A'] == $this->city)
                $suitRows[] = $data[$key];
        }

        //Rows contain digit and original need row
        $needRows = $this->getRow($suitRows);


        if($weight < 45){
            $minWeightPrice = $needRows['digits_row']['C'];
            $optPrice = $needRows['digits_row']['D'];

            $price = $weight * $optPrice;

            return ( ($minWeightPrice > $price) ? $minWeightPrice : $price );
        }


        if($typeCargo = 'gc'){
            $weightColumns = [
                'E' => 100,
                'F' => 250,
                'G' => 500,
                'H' => 1000,
                'I' => 2000,
                'J' => INF
            ];

            $price = $this->getPrice($weight, $weightColumns, $needRows);
        }
        elseif($typeCargo = 'dg'){
            $weightColumns = [
                'E' => 100,
                'F' => 250,
                'G' => INF,
            ];

            $price = $this->getPrice($weight, $weightColumns, $needRows);
        }
        else{
            $price = $weight * $needRows['digits_row']['D'];
        }

        return $price;
    }

    private function getPrice($weight, $weightColumns, $needRows){
        foreach ($weightColumns as $column => $weightColumn) {
            if($weight < $weightColumn){
                return $price = $needRows['digits_row'][$column] * $weight;
            }
        }
    }

    private function getRow($suitRows){
        $rowsDigits = [];

        //All value to digit
        foreach ($suitRows as $key => $row) {
            $rowsDigits[] = array_map('floatval', $row);
        }

        //Сравниваем значения отличные от нуля
        foreach ($rowsDigits as $key => $digits) {

            $digits = array_diff($digits, array(0,'',false,null));
            $currentMin = min($digits);

            if($minDigit === null){
                $keyRow = $key;
                $minDigit = $currentMin;
            }

            if( $currentMin < $minDigit ){
                $keyRow = $key;
                $minDigit = $currentMin;
            }
        }


       return [
            'original_row' => $suitRows[$keyRow],
            'digits_row' => $rowsDigits[$keyRow],
       ];
    }

    private function prepareNumbers(){
        $this->weight = floatval($this->weight);

        foreach ($this->sizeCargo as $key => $value) {
            $this->sizeCargo[$key] = floatval($value);
        }
    }


    public function getCountries(){
        $countries = [];
        $data = $this->getData();
        foreach ($data as $key => $value) {
            $countries[$value['B']] = $value['B'];
        }

        return $countries;
    }

    public function getCities(){
        $cities = [];
        $data = $this->getData();
        foreach ($data as $key => $value) {
            if($this->country == $value['B'])
                $cities[$value['A']] = $value['A'];
        }

        return $cities;
    }

    private function setSheets(){

        switch ($this->forCity) {
            case 'boryspol':
                    $this->sheets = ['gc' => 'sheet1', 'dg' => 'sheet2', 'hum' => 'sheet3', 'val' => 'sheet4'];
                break;
            case 'odessa':
                    $this->sheets = ['gc' => 'sheet5', 'dg' => 'sheet6', 'hum' => 'sheet7', 'val' => 'sheet8'];
                break;
            case 'lviv':
                    $this->sheets = ['gc' => 'sheet9', 'dg' => 'sheet10', 'hum' => 'sheet11', 'val' => 'sheet12'];
                break;
            case 'harkiv':
                    $this->sheets = ['gc' => 'sheet13', 'dg' => 'sheet14', 'hum' => 'sheet15', 'val' => 'sheet16'];
                break;
            case 'dnipro':
                    $this->sheets = ['gc' => 'sheet17', 'dg' => 'sheet18', 'hum' => 'sheet19', 'val' => 'sheet20'];
                break;

            default:
                break;
        }

    }


    public function getData(){
        $mps_option = get_option('gamma_mps');

        $data = $mps_option[$this->optionName][$this->sheets[$this->typeCargo]];

        array_shift($data);

        return $data;
    }



}
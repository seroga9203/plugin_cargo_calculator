<?php

/**
* DB class
*/
class GammaMPSPage{

    static private $instance = NULL;
    public $fields;
    public $option_name;
    public $option_groups;
    public $sections;
    public $page;
    public $items_page;

    function __construct(){
        add_action('admin_menu', array($this, 'add_gamma_mps_page'));
        add_action('admin_init', array($this, 'gamma_mps_settings'));

        //PAGES ID
        $this->page = 'gamma_mps_main';

        //OPTIONS ID
        $this->option_name = 'gamma_mps';

        //GROUPS
        $this->option_groups = array(
            'gamma_mps_option_group' => array(
                'option_name' => $this->option_name,
                'function_validate' => 'gamma_mps_validate',
                ),
        );

        //SECTIONS
        $this->sections = array(
            'download_table' => array(
                'title' => 'Основные настройки',
                'callbaback' => '',
                'page' => $this->page,
                ),
        );


        //Страницы плагина
        $this->items_page = array(
            'main' => array(
                'name' => 'MPS',
                'title' => 'Настройки MPS',
                'capability' => 'manage_options',
                'page' => $this->page,
                'function' => 'gamma_mps_options_page' ,
                ),
            );

        //Поля плагина
        $this->fields = array(
            'express_import' => array(
                'title' => 'Загрузите таблицу с тарифами в Украину',
                'page' => $this->page,
                'section' => 'download_table',
                'args' => array(
                    'type'      => 'file',
                    'id'        => 'express_import',
                    'desc'      => ''
                ),
            ),
            'express_export' => array(
                'title' => 'Загрузите таблицу с тарифами из Украины',
                'page' => $this->page,
                'section' => 'download_table',
                'args' => array(
                    'type'      => 'file',
                    'id'        => 'express_export',
                    'desc'      => ''
                ),
            ),
            'cargo_import' => array(
                'title' => 'Загрузите таблицу с тарифами cargo в Украину',
                'page' => $this->page,
                'section' => 'download_table',
                'args' => array(
                    'type'      => 'file',
                    'id'        => 'cargo_import',
                    'desc'      => ''
                ),
            ),
            'cargo_export' => array(
                'title' => 'Загрузите таблицу с тарифами cargo из Украины',
                'page' => $this->page,
                'section' => 'download_table',
                'args' => array(
                    'type'      => 'file',
                    'id'        => 'cargo_export',
                    'desc'      => ''
                ),
            ),
            'zones' => array(
                'title' => 'Загрузите таблицу с зонами доставки',
                'page' => $this->page,
                'section' => 'download_table',
                'args' => array(
                    'type'      => 'file',
                    'id'        => 'zones',
                    'desc'      => ''
                ),
            ),
        );


    }


    static public function instance(){
        if(is_null(self::$instance))
            return self::$instance = new self;
    }



    public function add_gamma_mps_page(){
        foreach ($this->items_page as $item_page) {
            add_options_page( $item_page['title'],  $item_page['name'], $item_page['capability'], $item_page['page'], array($this, $item_page['function']));
        }
    }

    public function gamma_mps_options_page(){
        ?>
        <div class="wrap">
            <h2><?php echo get_admin_page_title() ?></h2>

            <form action="options.php" method="POST" enctype="multipart/form-data">
                <?php
                    settings_fields( 'gamma_mps_option_group' );     // скрытые защитные поля
                    do_settings_sections( $this->page ); // секции с настройками (опциями).
                    submit_button();
                ?>
            </form>

        </div>
        <?php
    }

    public function gamma_mps_settings(){
        //GROUP
        // параметры: $option_group, $option_name, $sanitize_callback
        foreach ($this->option_groups as $group_id => $option_group) {
            register_setting( $group_id, $option_group['option_name'], array($this, $option_group['function_validate']) );
        }

        //SECTIONS
        // параметры: $id, $title, $callback, $page
        foreach ($this->sections as $section_id => $section) {
            add_settings_section( $section_id, $section['title'], $section['callbaback'], $section['page'] );
        }

        //FIELDS
        // параметры: $id, $title, $callback, $page, $section, $args
        foreach ($this->fields as $fild_id => $fild) {
           add_settings_field($fild_id, $fild['title'], array($this, 'mps_option_display_settings'), $fild['page'], $fild['section'],  $fild['args']);
        }

    }





    function mps_option_display_settings($args) {
        extract( $args );

        $option_name = $this->option_name;

        $o = get_option( $option_name );

        switch ( $type ) {
            case 'text':
                $o[$id] = esc_attr( stripslashes($o[$id]) );
                echo "<input class='regular-text' type='text' id='$id' name='" . $option_name . "[$id]' value='$o[$id]' />";
                echo ($desc != '') ? "<br /><span class='description'>$desc</span>" : "";
            break;
            case 'textarea':
                $o[$id] = esc_attr( stripslashes($o[$id]) );
                echo "<textarea class='code large-text' cols='50' rows='10' type='text' id='$id' name='" . $option_name . "[$id]'>$o[$id]</textarea>";
                echo ($desc != '') ? "<br /><span class='description'>$desc</span>" : "";
            break;
            case 'checkbox':
                $checked = ($o[$id] == 'on') ? " checked='checked'" :  '';
                echo "<label><input type='checkbox' id='$id' name='" . $option_name . "[$id]' $checked /> ";
                echo ($desc != '') ? $desc : "";
                echo "</label>";
            break;
            case 'select':
                echo "<select id='$id' name='" . $option_name . "[$id]'>";
                foreach($vals as $v=>$l){
                    $selected = ($o[$id] == $v) ? "selected='selected'" : '';
                    echo "<option value='$v' $selected>$l</option>";
                }
                echo ($desc != '') ? $desc : "";
                echo "</select>";
            break;
            case 'radio':
                echo "<fieldset>";
                foreach($vals as $v=>$l){
                    $checked = ($o[$id] == $v) ? "checked='checked'" : '';
                    echo "<label><input type='radio' name='" . $option_name . "[$id]' value='$v' $checked />$l</label><br />";
                }
                echo "</fieldset>";
            break;
            case 'file':

                echo "<input type='file' id='$id' name='" . $id ."' />";
                echo "<input type='hidden' id='$id' name='" . $option_name . "[$id]' />";
                echo ($desc != '') ? "<br /><span class='description'>$desc</span>" : "";
                if(isset($o[$id]) && !empty($o[$id])){
                    echo "<br /><span class='description'>[mps_excel name='$id' sheet='1 \or 2 \or 3 etc.']</span>";
                }


            break;
        }
    }


    public function gamma_mps_validate($options){
        global $gammaMPS;


        foreach ($options as $option_id => $option_val) {
            if(!$_FILES[$option_id]['error']){
                UploadFile::saveFile($_FILES[$option_id]);
                ExcelParser::instance(UploadFile::$file_data["full_path"]);

                $options[$option_id]['download_url'] = UploadFile::$info_dir_upload['baseurl'].'/mps_files/'.UploadFile::$file_data["filename"];

                switch ($option_id) {

                    case 'express_import':
                    case 'cargo_import':
                    case 'express_export':
                        $options[$option_id]['sheet1'] = ExcelParser::get_sheet(0);
                        $options[$option_id]['sheet2'] = ExcelParser::get_sheet(1);
                        $options[$option_id]['sheet3'] = ExcelParser::get_sheet(2);
                        break;
                    case 'cargo_export':
                            $options[$option_id]['sheet1'] = ExcelParser::get_sheet(0);
                            $options[$option_id]['sheet2'] = ExcelParser::get_sheet(1);
                            $options[$option_id]['sheet3'] = ExcelParser::get_sheet(2);
                            $options[$option_id]['sheet4'] = ExcelParser::get_sheet(3);
                            $options[$option_id]['sheet5'] = ExcelParser::get_sheet(4);
                            $options[$option_id]['sheet6'] = ExcelParser::get_sheet(5);
                            $options[$option_id]['sheet7'] = ExcelParser::get_sheet(6);
                            $options[$option_id]['sheet8'] = ExcelParser::get_sheet(7);
                            $options[$option_id]['sheet9'] = ExcelParser::get_sheet(8);
                            $options[$option_id]['sheet10'] = ExcelParser::get_sheet(9);
                            $options[$option_id]['sheet11'] = ExcelParser::get_sheet(10);
                            $options[$option_id]['sheet12'] = ExcelParser::get_sheet(11);
                            $options[$option_id]['sheet13'] = ExcelParser::get_sheet(12);
                            $options[$option_id]['sheet14'] = ExcelParser::get_sheet(13);
                            $options[$option_id]['sheet15'] = ExcelParser::get_sheet(14);
                            $options[$option_id]['sheet16'] = ExcelParser::get_sheet(15);
                            $options[$option_id]['sheet17'] = ExcelParser::get_sheet(16);
                            $options[$option_id]['sheet18'] = ExcelParser::get_sheet(17);
                            $options[$option_id]['sheet19'] = ExcelParser::get_sheet(18);
                            $options[$option_id]['sheet20'] = ExcelParser::get_sheet(19);
                        break;
                    case 'zones':
                            $options[$option_id]['sheet1'] = ExcelParser::get_sheet(0);
                        break;
                }

            }
            else{
                $o = get_option( $this->option_name );
                $errors_str = array(
                    'express_import' => 'Express import',
                    'express_export' => 'Express export',
                    'cargo_import' => 'Cargo import',
                    'cargo_export' => 'Cargo export',
                    'zones' => 'Zones',
                    );
                if(!isset($o[$option_id]) || empty($o[$option_id]))
                    add_settings_error( $this->option_name, $option_id, 'You do not download anyone table '.$errors_str[$option_id], 'error' );
                else
                   $options[$option_id] =  $o[$option_id];
            }
        }

        return $options;
    }


}



 ?>
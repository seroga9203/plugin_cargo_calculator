<?php

/**
* excelParser class
*/
class ExcelParser{

    static private $instance = NULL;
    static private $objPHPExcel;
    function __construct($path_excel){
       self::$objPHPExcel = PHPExcel_IOFactory::load($path_excel);
    }


    static public function get_sheet($index = 0){
        return $sheetData = self::$objPHPExcel->setActiveSheetIndex($index)->toArray(null,true,true,true);
    }


    static public function instance($path_excel){
        if(is_null(self::$instance))
            return self::$instance = new self($path_excel);
    }





}



 ?>
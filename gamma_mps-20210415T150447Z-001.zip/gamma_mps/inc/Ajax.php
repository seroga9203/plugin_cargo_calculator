<?php

include GAMMA_MPS_DIR.'inc/CargoCalculatorPrice.php';
/**
* Ajax
*/
class Ajax
{

    function __construct(){

        //calculator price
        add_action('wp_ajax_calculatePrice', array($this, 'calculatePrice'));
        add_action('wp_ajax_nopriv_calculatePrice', array($this, 'calculatePrice'));

        //calculator price
        add_action('wp_ajax_cargoCalculatePrice', array($this, 'cargoCalculatePrice'));
        add_action('wp_ajax_nopriv_cargoCalculatePrice', array($this, 'cargoCalculatePrice'));
    }


    public function calculatePrice(){
        $keys = ['type', 'country', 'weight', 'size', 'percentFuel'];
        $price = 0;
        //Соответсвие зон именам колонок xls
        $zones = [1 => 'B', 2=>'C', 3=>'D', 4=>'E', 5=>'F', 6=>'G', 7=>'H', 8=>'I', 9=>'J', 10=>'K', 11=>'L'];

        $postData = $this->getPostData($keys);

        $mps_option = get_option('gamma_mps');


        if($postData['type'] == 'express_export'){
            $price_rows = $mps_option['express_export']['sheet3'];
        }
        elseif($postData['type'] == 'express_import'){
            $price_rows = $mps_option['express_import']['sheet3'];
        }
        array_shift($price_rows);

        if( ($postData['size']*200) <=  $postData['weight'] ){
            $weight = $postData['weight'];
        }
        else{
            $weight = $postData['size']*200;
        }



        for ($i=0; $i < count($price_rows); $i++) {
            $current_weight = $price_rows[$i]['A'];

            if($i == 0){
                $prev_weight = $current_weight;
            }
            else{
                $prev_weight = $price_rows[$i-1]['A'];
            }

            if($i < count($price_rows)){
                $next_weight = $price_rows[$i+1]['A'];
            }

            if($current_weight == $weight){
                $price = $price_rows[$i][ $zones[ $postData['country'] ] ];
                break;
            }

            if( $weight > $prev_weight && $weight < $next_weight ){
                $price = $price_rows[$i+1][ $zones[ $postData['country'] ] ];
                break;
            }
        }

        //Add percentFuel to price
        $price = $price+$price*$postData['percentFuel'];

        wp_send_json_success( $price, $status_code = 1 );
    }


    public function cargoCalculatePrice(){
        $keys = ['typeCargo', 'country', 'city', 'weight', 'sizeCargo', 'forCity', 'percentFuel', 'subAction'];
        $price = 0;

        $postData = $this->getPostData($keys);

        $calulator = new CargoCalculatorPrice($postData);

        if($subAction = $postData['subAction']){
            wp_send_json_success( $calulator->$subAction(), $status_code = 1 );
        }

        $price = $calulator->calculatePrice();

        //Add percentFuel to price
        $price = $price+$price*$postData['percentFuel'];

        if($price)
            $response = "<div class='text-center h4'>Вартість перевезення вантажу становить <span class='text-success'>$price грн.</span></div>";
        else
            $response = "<div class='text-center h4'>Вартість доставки розраховуэться індивідуально, зверніться будь ласка до менеджера.</div>";


       wp_send_json_success( $response, $status_code = 1 );
    }


    protected function getPostData($keys){
        $data = [];
        foreach ($keys as $key) {
            $data[$key] = isset($_POST[$key]) ? $_POST[$key]:null;
        }
        return $data;
    }
}

new Ajax();
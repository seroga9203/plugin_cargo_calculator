<?php

/**
* DB class
*/
class GammaMPSDb{

    static private $instance = NULL;
    private $table_name;

    function __construct(){
        global $wpdb;

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        $this->table_name = $wpdb->prefix.'gamma_mps';
    }


    static public function instance(){
        if(is_null(self::$instance))
            return self::$instance = new self;
    }

    public function create_table(){

        global $wpdb;
        if(!$this->isset_mps_table()) {
            $sql = "CREATE TABLE " . $this->table_name . " (
              id mediumint(9) NOT NULL AUTO_INCREMENT,
              table_name VARCHAR(55) NOT NULL,
              table_data text NOT NULL,
              PRIMARY KEY  (id)
            );";

            return $result = dbDelta($sql);
        }

        return $result = false;
    }

    public function delete_table(){
        global $wpdb;
        if($this->isset_mps_table()) {
            $wpdb->query("DROP TABLE ". $this->table_name .";");
        }
    }

    public function insert(){

    }

    public function update(){

    }

    public function delete(){

    }

    protected function isset_mps_table(){
        global $wpdb;

        if($wpdb->get_var("SHOW TABLES LIKE '$this->table_name'") != $this->table_name)
            return false;

        return true;
    }






}



 ?>
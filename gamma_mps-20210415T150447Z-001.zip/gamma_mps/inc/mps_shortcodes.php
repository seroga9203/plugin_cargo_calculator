<?php


/**
* MpsShortcodes class
*/
class MpsShortcodes{

    static private $instance = NULL;
    private $shortcodes;

    function __construct(){
        $this->shortcodes = array(
            'mps_excel',
            'form_tracking',
            'express_calculator_price',
            'cargo_calculator_price',
            );

        $this->init();

    }

    static public function instance(){
        if(is_null(self::$instance))
            return self::$instance = new self;
    }


    private function init(){
        foreach ($this->shortcodes as $shortcode) {
            add_shortcode( $shortcode, array($this, 'show_'.$shortcode) );
        }
    }

    public function show_form_tracking( $atts ) {
        global $mps;
        $html = '';
        $atts = shortcode_atts( array(
            'text_title' => 'Форма заявки',
            'text_button' => 'Відправити',
            'placeholder' => '№ заявки'
        ), $atts );
        extract($atts);

        ob_start();
        View::render('shortcodes/form_tracking', [
                'text_title' => $text_title,
                'text_button' => $text_button,
                'placeholder' => $placeholder
            ]);
        return $html = ob_get_clean();

    }




    /*====================================================CALCULATOR=========================================================*/
    /*====================================================CALCULATOR=========================================================*/
    /*====================================================CALCULATOR=========================================================*/
    /*====================================================CALCULATOR=========================================================*/
    /*====================================================CALCULATOR=========================================================*/



    public function show_express_calculator_price($atts){
        $atts = shortcode_atts( array(
            'name' => 'express_export',
            'percent_fuel' => 0.15
        ), $atts );
        $mps_option = get_option('gamma_mps');
        $zones = $mps_option['zones']['sheet1'];
        array_shift($zones);

        ob_start();
        View::render('shortcodes/express_calculator_price', [
                'zones' => $zones,
                'atts' => $atts
            ]);
        return $html = ob_get_clean();
    }

    public function show_cargo_calculator_price($atts){

        $atts = shortcode_atts( array(
            'for_city' => 'boryspol',
            'percent_fuel' => 0.15
        ), $atts );

        ob_start();
        View::render('shortcodes/cargo_calculator_price', [
                'atts' => $atts,
            ]);
        return $html = ob_get_clean();
    }





    /*====================================================EXEL=========================================================*/
    /*====================================================EXEL=========================================================*/
    /*====================================================EXEL=========================================================*/
    /*====================================================EXEL=========================================================*/
    /*====================================================EXEL=========================================================*/




    public function show_mps_excel($atts){

        $atts = shortcode_atts( array(
            'name' => 'express_import',
            'sheet' => 0,
            'class' => '',
        ), $atts );

        extract($atts);
        ?>
        <?php  $mps_option = get_option('gamma_mps'); ?>
        <?php if(isset($mps_option[$name]['sheet'.$sheet])): ?>
            <?php ob_start(); ?>
            <div class="container-fluid block-content">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 welcome-text">
                        <!-- <table class="table table-hover table-bordered taxes" style="margin-top: -25px"> -->
                        <?php if($name != 'zones'): ?>
                            <?php $this->full_table($mps_option, $name, $sheet, $class); ?>
                        <?php else: ?>
                            <?php $this->half_table($mps_option, $name, $sheet, $class, 0, 118); ?>
                            <?php $this->half_table($mps_option, $name, $sheet, $class, 117, 234); ?>
                        <?php endif; ?>

                        <?php if(false): ?>
                        <h5>Загрузить таблицу в .XLSX: <a class="btn btn-success" href="<?php echo $mps_option[$name]['download_url']; ?>">Загрузить</a></h5>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php $html = ob_get_clean(); ?>
        <?php endif; ?>
        <?php
        return $html;
    }

    private function full_table($mps_option, $name, $sheet, $class){

        ?>
        <table class="table table-hover table-bordered mps_xls sheet-<?php echo $sheet; ?> <?php echo $name; ?> <?php echo $class; ?>" style="margin-top: -25px">
        <?php foreach ($mps_option[$name]['sheet'.$sheet] as $row => $cols): ?>
                <?php if(!$cols['A'] && !$cols['B'] && !$cols['C']) continue; ?>
                <?php echo $row==1 ? '<thead><tr>':'<tr>'; ?>
                    <?php foreach ($cols as $col): ?>
                            <?php echo $row==1 ? '<th>':'<td>'; ?>
                                <?php echo $col; ?>
                            <?php echo $row==1 ? '</th>':'</td>'; ?>
                    <?php endforeach; ?>
                <?php echo $row==1 ? '</tr></thead>':'</tr>'; ?>
        <?php endforeach; ?>
        </tbody>
        </table>
        <?php
    }

    private function half_table($mps_option, $name, $sheet, $class, $start_row, $end_row){
        $count = 1;

        ?>

        <div class="col-sm-6 col-md-6 col-lg-6 welcome-text">
        <table class="table table-hover table-bordered mps_xls sheet-<?php echo $sheet; ?> <?php echo $name; ?> <?php echo $class; ?>" style="margin-top: -25px">
        <?php foreach ($mps_option[$name]['sheet'.$sheet] as $row => $cols): ?>
                <?php if($count <= $start_row && $count > 1) {$count++; continue;} ?>
                <?php if($count >= $end_row) break; ?>
                <?php echo $row==1 ? '<thead><tr>':'<tr>'; ?>
                    <?php foreach ($cols as $col): ?>
                            <?php echo $row==1 ? '<th>':'<td>'; ?>
                                <?php echo $col; ?>
                            <?php echo $row==1 ? '</th>':'</td>'; ?>
                    <?php endforeach; ?>
                <?php echo $row==1 ? '</tr></thead>':'</tr>'; ?>
                <?php $count++; ?>
        <?php endforeach; ?>
        </tbody>
        </table>
        </div>

        <?php
    }





}




?>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<div class="container-fluid calculator_price">
    <div class="row">
        <div class="col-xs-12 col-md-12">
            <h3>Калькулятор вартості</h3>
        </div>
    </div>
    <div class="row ">
        <form action="" id="calculator_price" role="form">
            <div class="form-group clearfix">
                <div class=" col-xs-12 col-md-5">
                    <div class="row">
                        <div class=" col-xs-12 col-md-5">
                            <label for="calc_country">Виберіть країну :</label>
                        </div>
                        <div class=" col-xs-12 col-md-7">
                            <div class="default-inp">
                                <select id="calc_country" name="calc_country" autocomplete="off">
                                    <option value="" selected="">Оберіть країну</option>
                                    <?php foreach ($zones as $zone): ?>
                                        <option value="<?php echo $zone['B'] ?>"><?php echo $zone['A'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                            <p class="calc_error">Error</p>
                        </div>
                    </div>
                </div>
                <div class=" col-xs-12 col-md-7">
                    <div class="row">
                        <div class=" col-xs-12 col-md-5 col-md-offset-1">
                            <label for="calc_zone">Зона перевезення </label>
                        </div>
                        <div class=" col-xs-12 col-md-6">
                            <div class="default-inp">
                                <input type="text" id="calc_zone" name="calc_zone" value="№" autocomplete="off">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group clearfix">
                <div class=" col-xs-12 col-md-12">
                    <div class="row">
                        <div class=" col-xs-12 col-md-5">
                            <div class="row">
                                <div class=" col-xs-12 col-md-5">
                                    <label for="calc_weight">Вкажіть вагу, кг. :</label>
                                </div>
                                <div class=" col-xs-12 col-md-7">
                                    <div class="default-inp">
                                        <input type="text" id="calc_weight" name="calc_weight" placeholder="0" autocomplete="off">
                                    </div>
                                    <span class="hint">Вага від 0,5 кг до 300 кг</span>
                                    <p class="calc_error">Error</p>
                                </div>
                            </div>
                        </div>

                        <div class=" col-xs-12 col-md-7">
                            <div class="row">
                                <div class=" col-xs-12 col-md-5 col-md-offset-1">
                                    <label for="">Вкажіть розміри вантажу :</label>
                                </div>
                                <div class=" col-xs-12 col-md-2">
                                    <div class="default-inp">
                                        <input type="text" id="calc_size_width" name="calc_size_width" placeholder="0" autocomplete="off">
                                    </div>
                                    <span class="hint">Ширина, м.</span>
                                    <p class="calc_error">Error</p>
                                </div>
                                <div class=" col-xs-12 col-md-2">
                                    <div class="default-inp">
                                        <input type="text" id="calc_size_length" name="calc_size_length" placeholder="0" autocomplete="off">
                                    </div>
                                    <span class="hint">Довжина, м.</span>
                                    <p class="calc_error">Error</p>
                                </div>
                                <div class=" col-xs-12 col-md-2">
                                    <div class="default-inp">
                                        <input type="text" id="calc_size_height" name="calc_size_height" placeholder="0" autocomplete="off">
                                    </div>
                                    <span class="hint">Висота, м.</span>
                                    <p class="calc_error">Error</p>
                                </div>
                            </div>

                        </div>


                    </div>
                </div>
            </div>
            <div class=" col-xs-12 col-md-12">
                <div id="calc_result" class="calc_result"></div>
            </div>
            <div class="col-xs-12 col-md-12">
                <input type="hidden" id="calc_type" name="calc_type" value="<?php echo $atts['name']; ?>">
                <input type="hidden" id="percent_fuel" name="percent_fuel" value="<?php echo $atts['percent_fuel']; ?>">
                <p class="calc_button"><button type="submit" class="btn btn-success">Розрахувати</button></p>
            </div>

        </form>
    </div>
</div>
<script>
    (function($) {
        $(document).ready(function() {
            $('#calc_country').select2();
        });
    })(jQuery);
</script>

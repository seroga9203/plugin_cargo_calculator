<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<div class="container-fluid calculator_price">
    <div class="row">
        <div class="col-xs-12 col-md-12">
            <h3>Калькулятор вартості</h3>
        </div>
    </div>


    <div class="row ">
        <form action="" id="cargo_calculator_price" role="form">
            <div class="form-group clearfix">
                <div class=" col-xs-12 col-md-4">
                    <label for="cargo_calc_type">Оберіть тип вантажу :</label>
                    <div class="default-inp">
                        <select id="cargo_calc_type" name="cargo_calc_type" autocomplete="off">
                            <option value="" >Оберіть тип вантажу</option>
                            <option value="gc">Генеральний вантаж</option>
                            <option value="dg">Небезпечний вантаж</option>
                            <option value="hum">Вантаж людських залишків</option>
                            <option value="val">Цінний вантаж</option>
                        </select>
                    </div>
                    <p class="calc_error">Error</p>
                </div>
                <div class=" col-xs-12 col-md-4">
                    <label for="cargo_calc_country">Оберіть країну :</label>
                    <div class="default-inp form-group">
                        <div class="refresh"><i class="fa fa-refresh fa-spin" aria-hidden="true"></i></div>
                        <select id="cargo_calc_country" name="cargo_calc_country" class="form-control" autocomplete="off">
                            <option value="" >Оберіть країну</option>
                        </select>
                    </div>
                    <p class="calc_error">Error</p>
                </div>
                <div class=" col-xs-12 col-md-4">
                    <label for="cargo_calc_city">Оберіть місто :</label>
                    <div class="default-inp form-group">
                        <div class="refresh"><i class="fa fa-refresh fa-spin" aria-hidden="true"></i></div>
                        <select id="cargo_calc_city" name="cargo_calc_city" autocomplete="off">
                            <option value="" >Оберіть місто</option>
                        </select>
                    </div>
                    <p class="calc_error">Error</p>
                </div>
            </div>
            <div class="form-group clearfix">
                <div class=" col-xs-12 col-md-4">
                    <label for="cargo_calc_weight">Вкажіть вагу, кг. :</label>
                    <div class="default-inp">
                        <input type="text" id="cargo_calc_weight" name="cargo_calc_weight" placeholder="0" autocomplete="off">
                    </div>
                    <p class="calc_error">Error</p>
                </div>
                <div class=" col-xs-12 col-md-8">
                    <div class="row">
                        <label for="">Вкажіть розміри вантажу :</label>
                    </div>
                    <div class="row">
                        <div class=" col-xs-4 col-md-4">
                            <div class="default-inp">
                                <input type="text" id="cargo_calc_size_width" name="cargo_calc_size_width" placeholder="0" autocomplete="off">
                            </div>
                            <span class="hint">Ширина, м.</span>
                            <p class="calc_error">Error</p>
                        </div>
                        <div class=" col-xs-4 col-md-4">
                            <div class="default-inp">
                                <input type="text" id="cargo_calc_size_length" name="cargo_calc_size_length" placeholder="0" autocomplete="off">
                            </div>
                            <span class="hint">Довжина, м.</span>
                            <p class="calc_error">Error</p>
                        </div>
                        <div class=" col-xs-4 col-md-4">
                            <div class="default-inp">
                                <input type="text" id="cargo_calc_size_height" name="cargo_calc_size_height" placeholder="0" autocomplete="off">
                            </div>
                            <span class="hint">Висота, м.</span>
                            <p class="calc_error">Error</p>
                        </div>
                    </div>

                </div>
            </div>
            <div class=" col-xs-12 col-md-12">
                <div id="cargo_calc_result" class="cargo_calc_result"></div>
            </div>
            <div class="col-xs-12 col-md-12">
                <input type="hidden" id="for_city" name="for_city" value="<?php echo $atts['for_city']; ?>">
                <input type="hidden" id="percent_fuel" name="percent_fuel" value="<?php echo $atts['percent_fuel']; ?>">
                <p class="calc_button"><button type="submit" class="btn btn-success">Розрахувати</button></p>
            </div>

        </form>
    </div>
</div>
<script>
    (function($) {
        $(document).ready(function() {
            $('#cargo_calc_type, #cargo_calc_country, #cargo_calc_city').select2();
        });
    })(jQuery);
</script>
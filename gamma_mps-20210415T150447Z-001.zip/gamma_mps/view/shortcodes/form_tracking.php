<div class="container-fluid block-content">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 wow fadeInRight" data-wow-delay="0.1s" data-wow-duration="0.3s">

            <form id="contactForm" class="reply-form form-inline" method="post" action="">
                <div class="row form-elem">
                    <div class="col-md-offset-2 col-md-8 col-sm-12 form-elem">
                        <h4><?php echo $text_title; ?></h4>
                        <div class="default-inp form-elem">
                            <i class="fa fa-truck"></i>
                            <input type="text" name="order_id" id="sender" placeholder="<?php echo $placeholder; ?>"  required autocomplete="off">
                        </div>
                        <div class="form-elem">
                            <?php wp_nonce_field('watch_tracking','mps_watch_tracking'); ?>
                            <button type="submit" style="margin-bottom: 20px;" class="btn btn-success btn-default"><?php echo $text_button; ?></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <?php //TEMP!!!!!!!!!!!!!!!! ?>
        <?php if($mps->pageControler->find_order): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p>Ваш запит на відстеження відправлення номер:<strong><?php echo $mps->pageControler->find_order; ?></strong>, було выдправлено. Ми з Вами звяжемося протягом 20 хвилин.</p>
            </div>

        <?php endif; ?>

        <?php //Original!!!! ?>
        <?php //if($mps->pageControler->find_order || is_null($mps->pageControler->find_order)): ?>
            <?php //render_search_order_table($mps->pageControler->find_order); ?>
        <?php //endif; ?>
        </div>
    </div>
</div>
<?php
if(!defined('ABSPATH'))
    die('Невозможно подключить плагин MPS!!!');
/*
Plugin Name: MPS
Description: Настройки темы MPS
Version: 1.0
Author: gamma-iron
Author URI: http://gamma-iron.com.ua/
Plugin URI: http://gamma-iron.com.ua/
*/

//CONSTANT



define('GAMMA_MPS_DIR', plugin_dir_path(__FILE__));
define('GAMMA_MPS_URL', plugin_dir_url(__FILE__));

register_activation_hook(__FILE__, array('GammaMPS', 'gamma_mps_activation'));
register_deactivation_hook(__FILE__, array('GammaMPS', 'gamma_mps_deactivation'));
register_uninstall_hook(__FILE__, array('GammaMPS', 'gamma_mps_uninstall'));

add_action( 'plugins_loaded', array( 'GammaMPS', 'instance' ) );

/**
* Main class
*/
class GammaMPS{

    private static $instance = NULL;
    public static $mpsDb;

    public static $error;

    function __construct(){



        //Require extra files
        require_once GAMMA_MPS_DIR.'/inc/gamma_mps_db.php';
        require_once GAMMA_MPS_DIR.'/inc/View.php';
        require_once GAMMA_MPS_DIR.'/inc/gamma_mps_page.php';
        require_once GAMMA_MPS_DIR.'/inc/Ajax.php';
        require_once GAMMA_MPS_DIR.'/inc/excelParser.php';
        require_once GAMMA_MPS_DIR.'/inc/mps_shortcodes.php';
        require_once GAMMA_MPS_DIR.'/lib/UploadFile.php';
        require_once GAMMA_MPS_DIR.'lib/PHPExcel/PHPExcel/IOFactory.php';

        $this->init();
    }


    public static function instance(){
        if(is_null(self::$instance))
            return self::$instance = new self;
        else
            return self::$instance;
    }

    //INSTAL PLUGIN

    public function init(){

        //Properies
        self::$mpsDb = GammaMPSDb::instance();
        GammaMPSPage::instance();
        MpsShortcodes::instance();
        self::$error = array();

    }

    public static function set_error($error){
        self::$error[] = $error;
    }

    public static function gamma_mps_activation() {

        if ( ! current_user_can( 'activate_plugins' ) )
            return;

        //self::$mpsDb->create_table();
    }

    public static function gamma_mps_deactivation() {
        if ( ! current_user_can( 'activate_plugins' ) )
            return;

        unregister_setting( 'gamma_mps_option_group', "gamma_mps" );

        return true;
    }

    public static function gamma_mps_uninstall(){
        if ( ! current_user_can( 'activate_plugins' ) )
            return;

        // Важно: проверим тот ли это файл, который
        // был зарегистрирован во время удаления плагина.
        if ( __FILE__ != WP_UNINSTALL_PLUGIN )
            return;

        self::$mpsDb->delete_table();
        delete_option("gamma_mps");
    }





}


global $gammaMPS;
if(!$gammaMPS)
    $gammaMPS = gammaMPS::instance();






 ?>